package network;

public class emailtest {
    /**
     * SMTP 邮件的传输协议
     *
     * POP3，IMAP邮件读取协议
     */
}
