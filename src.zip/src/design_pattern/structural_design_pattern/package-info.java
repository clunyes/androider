package design_pattern.structural_design_pattern;
//结构型设计模式
