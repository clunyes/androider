package design_pattern.structural_design_pattern.adapter;

public interface TwoPinSocket {
    void chargeWithTwoPin();

    int voltage();
}
