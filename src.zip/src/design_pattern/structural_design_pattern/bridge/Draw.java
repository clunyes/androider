package design_pattern.structural_design_pattern.bridge;

public interface Draw {

    void drawCircle(int radius, int x, int y);
}
