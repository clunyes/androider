package design_pattern.structural_design_pattern.proxy.base;

public interface SendGift {
    public void sendFlower();

    public void sendCake();

    void goShopping();
}
