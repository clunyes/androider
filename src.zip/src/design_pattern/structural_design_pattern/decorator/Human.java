package design_pattern.structural_design_pattern.decorator;

public interface Human {
    void wearClothes();
    void walkToWhere();
}
