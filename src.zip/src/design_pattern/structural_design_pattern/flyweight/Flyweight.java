package design_pattern.structural_design_pattern.flyweight;

public interface Flyweight {
    void operation(String str);
}
