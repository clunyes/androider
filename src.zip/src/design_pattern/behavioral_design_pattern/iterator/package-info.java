package design_pattern.behavioral_design_pattern.iterator;
/**
提供一种方法顺序访问一个聚合对象中的各种元素，而又不暴露该对象的内部表示。*/
/**
 * java的迭代器
 */
