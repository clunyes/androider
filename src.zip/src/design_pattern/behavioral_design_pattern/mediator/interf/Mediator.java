package design_pattern.behavioral_design_pattern.mediator.interf;

public interface Mediator {

    void colleageChange(Colleage colleage);
}
