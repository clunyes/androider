package design_pattern.behavioral_design_pattern.observer;

public interface Observer {

    void update(Subject subject);
}
