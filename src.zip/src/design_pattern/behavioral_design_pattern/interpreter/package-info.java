package design_pattern.behavioral_design_pattern.interpreter;
/**
 * interpreter模式：解释器模式，然而我并没有理解这个模式，sorry
 */