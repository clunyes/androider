package design_pattern.behavioral_design_pattern.strategy;

public interface MemberStrategy {
    double calcPrice(double booksPrice);
}
