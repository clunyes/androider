package design_pattern.behavioral_design_pattern.command;

public interface Command {
    void excute();
}
