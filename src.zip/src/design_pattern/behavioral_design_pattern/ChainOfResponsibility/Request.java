package design_pattern.behavioral_design_pattern.ChainOfResponsibility;

public class Request {
    private String requestStr;

    public String getRequestStr() {
        return requestStr;
    }

    public void setRequestStr(String str) {
        this.requestStr = str;
    }
}
