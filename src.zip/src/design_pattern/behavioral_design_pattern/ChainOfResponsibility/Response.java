package design_pattern.behavioral_design_pattern.ChainOfResponsibility;

public class Response {
    private String responseStr;

    public void setResponseStr(String respStr) {
        responseStr = respStr;
    }

    public String getResponseStr() {
        return responseStr;
    }
}
