package design_pattern.behavioral_design_pattern.visitor;

public interface Element {

    void accept(Visitor visitor);
}
