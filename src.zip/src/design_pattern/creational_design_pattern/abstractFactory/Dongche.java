package design_pattern.creational_design_pattern.abstractFactory;

public class Dongche implements Train {
    @Override
    public void run() {
        System.out.println("CRh动车组造好了，开动了");
    }
}
