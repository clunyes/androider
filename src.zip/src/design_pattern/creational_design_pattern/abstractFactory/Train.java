package design_pattern.creational_design_pattern.abstractFactory;

public interface Train {
    void run();
}
