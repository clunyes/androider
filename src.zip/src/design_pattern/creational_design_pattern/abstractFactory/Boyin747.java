package design_pattern.creational_design_pattern.abstractFactory;

public class Boyin747 implements Plane {
    @Override
    public void fly() {
        System.out.println("波音747造好了，起飞了");
    }
}
