package design_pattern.creational_design_pattern.abstractFactory;

public class Boyin757 implements Plane {
    @Override
    public void fly() {
        System.out.println("我的天，波音757都造出来了，起飞了");
    }
}
