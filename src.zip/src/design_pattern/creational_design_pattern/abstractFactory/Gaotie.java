package design_pattern.creational_design_pattern.abstractFactory;

public class Gaotie implements Train {
    @Override
    public void run() {
        System.out.println("牛逼了，高铁都造好了，开动了");
    }
}
