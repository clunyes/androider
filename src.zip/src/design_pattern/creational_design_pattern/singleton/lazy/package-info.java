package design_pattern.creational_design_pattern.singleton.lazy;
//饿汉单例