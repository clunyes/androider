package design_pattern.creational_design_pattern.factoryMethod;

public class DoorB implements Door{

    public DoorB(){
        System.out.println("制造了doorB");
    }
}
