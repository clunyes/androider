package design_pattern.creational_design_pattern.factoryMethod;

public class DoorA implements Door {

    public DoorA() {
        System.out.println("制造了DoorA");
    }
}
