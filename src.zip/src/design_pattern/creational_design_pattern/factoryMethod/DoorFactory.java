package design_pattern.creational_design_pattern.factoryMethod;

public interface DoorFactory {
    Door factory();
}
