package algorithms.冒泡;

public class 冒泡排序说明 {
    /**
     * 相邻元素两两比较，比较完一趟，最值出现在末尾
     */
}
