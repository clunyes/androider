package algorithms.hash;

public class 装填因子 {
    /**
     * 又叫扩容因子
     * 散列表中元素个数和散列表长度比
     */
}
