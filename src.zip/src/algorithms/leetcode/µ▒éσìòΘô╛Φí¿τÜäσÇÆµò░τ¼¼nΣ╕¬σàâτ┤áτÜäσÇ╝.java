package algorithms.leetcode;

public class 求单链表的倒数第n个元素的值 {
    /**
     * 两个指针去走，一个先走到n-1，另一个在第0个
     * 两个指针一起开始往后走，先走的指针取到的节点为null，另一个就是倒数第n个。
     */

}
