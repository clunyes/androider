package algorithms.leetcode.合并K个排序链表;

public class ListNode {
    int val;
    ListNode next;

    ListNode(int x) {
        val = x;
    }
}
