package algorithms.插入;

public class 插入排序说明 {
    /**
     * 将待排序序列第一个元素看做一个有序序列，把第二个元素到最后一个元素当成是未排序序列；
     */
}
