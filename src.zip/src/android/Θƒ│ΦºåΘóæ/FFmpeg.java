package android.音视频;

public class FFmpeg {
    /**
     *
     * 它功能强大，用途广泛，大量用于视频网站和商业软件（比如 Youtube 和 iTunes），
     * 也是许多音频和视频格式的标准编码/解码实现。
     *
     */
}
