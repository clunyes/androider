package android.webview;

public class JavascriptInterface {
    /**
     *  android 4.2加入的安全限制，4.1之前需要手动加入安全
     */

}
