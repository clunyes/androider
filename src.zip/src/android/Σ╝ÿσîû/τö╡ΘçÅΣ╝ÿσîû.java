package android.优化;

public class 电量优化 {
    /**
     * 1. FLAG_KEEP_SCREEN_ON 屏幕常亮，在业务完成时，清除该flag
     * 2. 唤醒锁，用完及时释放唤醒锁
     * 3. 定位，设置合适的更新频率
     */
}
