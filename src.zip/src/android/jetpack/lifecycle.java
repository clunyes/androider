package android.jetpack;

public class lifecycle {
    /**
     * lifecycle
     *
     * LifecycleOwner LifecycleRegistry，注册事件，addObserver 加入观察者，
     * 将原本堆积在onresume，onpause中的大量的逻辑转移到不同业务的Observer（LifecycleObserver），
     * 业务更内聚。
     *
     */
}
