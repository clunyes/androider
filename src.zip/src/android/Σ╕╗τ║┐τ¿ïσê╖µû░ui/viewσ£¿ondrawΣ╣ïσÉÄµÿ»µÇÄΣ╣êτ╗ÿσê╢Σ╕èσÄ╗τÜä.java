package android.主线程刷新ui;

public class view在ondraw之后是怎么绘制上去的 {
}
