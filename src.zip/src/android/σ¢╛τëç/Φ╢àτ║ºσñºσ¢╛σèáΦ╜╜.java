package android.图片;

public class 超级大图加载 {
    /**
     * 使用BitmapRegionDecoder  decodeRegion,将大图的部分，展示到当前的rect矩形中去。
     *
     * 拖动，缩放手势操作对应完善
     */
}
