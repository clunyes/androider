package android.recyclerview;

public class diffutils {
    /**
     * DiffUtil使用场景：
     *
     * 存在更新前和更新后的两个数据集合可以用来对比；
     * 避免更新页面闪烁
     * 部分数据刷新
     *
     * 建议直接使用BRAVH
     */
}
