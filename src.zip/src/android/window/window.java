package android.window;

public class window {
    /**
     * Activity要管理View需要通过Window来间接管理的。Window通过addView()、removeView()、updateViewLayout()这三个方法来管理View的。
     */
}
