package android.service;

public class service混合启动 {
    /**
     * Intent  intent=new Intent(MainActivity.this,MyService.class);
     * bindService(intent,serviceConnect,BIND_AUTO_CREATE);
     * startService(intent);
     */
}
