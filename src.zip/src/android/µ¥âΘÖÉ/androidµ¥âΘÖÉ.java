package android.权限;

public class android权限 {
    /**
     * 动态获取的权限：读写权限，相机权限，地理位置
     * 静态权限：网络权限，允许安装包权限，震动权限，传感器权限
     */
}
