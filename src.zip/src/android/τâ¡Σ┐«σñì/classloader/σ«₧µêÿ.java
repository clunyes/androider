package android.热修复.classloader;

public class 实战 {
    /**
     * https://juejin.im/post/5a0ad2b551882531ba1077a2 通过dex替换，classloader原理，8.0之后优先级取消咋弄
     *
     * 不同dex调用的CLASS_ISPREVERIFIED问题
     * QQ 空间补丁方案就是使用javaassist 插桩的方式解决了CLASS_ISPREVERIFIED的难题。
     */
}
