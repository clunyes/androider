package android.热修复.不同方案;

public class sophix {
    /**
     * Sophix 结合了 Tinker 和 Robust 和优点，支持类替换、so替换、资源替换，立即生效，但是这个框架没有开源，是收费的。
     *
     * 同时采用了底层替换和类加载方案
     */
}
