package android.序列化;

public class serializable {
    /**
     * 使用了反射，使用
     *
     * 可以复写writeObject readObject，效率不错
     */
}
