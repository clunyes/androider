package datastructure.红黑树.插入.插入情景42;

public class 插入情景42 {
    /**
     * 叔叔结点不存在或为黑结点，并且插入结点的父亲结点是祖父结点的左子结点
     */
}
