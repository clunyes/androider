package datastructure.图.广度优先;

public class 广度优先搜索 {
    /**
     * 其别名又叫BFS，属于一种盲目搜寻法，目的是系统地展开并检查图中的所有节点，以找寻结果。
     * 换句话说，它并不考虑结果的可能位置，彻底地搜索整张图，直到找到结果为止。
     */
    /**
     * 步骤参开 https://www.jianshu.com/p/bff70b786bb6
     */
}
