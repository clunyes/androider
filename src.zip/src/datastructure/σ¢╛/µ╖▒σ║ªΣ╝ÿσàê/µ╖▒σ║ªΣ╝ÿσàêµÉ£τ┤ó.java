package datastructure.图.深度优先;

public class 深度优先搜索 {
    /**
     * 深度优先搜索是图论中的经典算法
     * 其过程简要来说是对每一个可能的分支路径深入到不能再深入为止，而且每个节点只能访问一次。
     */
    /**
     * 步骤参开 https://www.jianshu.com/p/bff70b786bb6
     */

}
