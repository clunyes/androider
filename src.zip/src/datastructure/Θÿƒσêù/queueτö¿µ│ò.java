package datastructure.队列;

public class queue常用操作 {
}
