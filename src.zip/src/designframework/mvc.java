package designframework;

public class mvc {
    /**
     * 1. view:xml布局文件
     * 2. model:处理相关数据
     * 3. controller:activity fragment
     *
     * 问题：view和controller耦合非常紧密，2000行3000行的activity fragment
     */
}
