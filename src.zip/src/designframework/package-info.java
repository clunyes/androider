package designframework;
//这里讨论的是架构模式，不是设计模式。