package javatest.变量;

public class String的各个 {
    /**
     * String是final类不能被继承且为字符串常量，而StringBuilder和StringBuffer均为字符串变量。
     */
    /**
     * StringBuilder（非线程安全）
     * StringBuffer（线程安全的）
     */
}
