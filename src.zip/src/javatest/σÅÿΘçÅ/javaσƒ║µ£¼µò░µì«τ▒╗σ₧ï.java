package javatest.变量;

public class java基本数据类型 {
    /**
     * 先来说说Java的基本数据类型和引用类型
     * 1. 八大基本数据类型：Byte，short，int，long，double，float，boolean，char，其中占一个字节的是byte，short和char占两个字节，
     * int，float占四个字节，double和long占8个字节，boolean只有true和false，这八种数据变量中直接存储值
     *
     * 2. String类型属于引用类型，变量中存储的是地址，对应的地址存储数据
     */
}
