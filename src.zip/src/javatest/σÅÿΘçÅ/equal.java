package javatest.变量;

public class equal {
    /**
     * equals是判断两个变量或者实例指向同一个内存空间的值是不是相同
     *
     * 而==是判断两个变量或者实例是不是指向同一个内存空间
     */
}
