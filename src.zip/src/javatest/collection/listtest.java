package javatest.collection;

public class listtest {
    /**
     * 主要讲一下，arraylist 和linkedlist的区别
     *
     * arraylist优势是查询，linkedlist优势插入
     *
     * Vector同步
     *
     * stack 栈继承自vector,后进先出的堆栈
     *
     * Collections.synchronizedList 实现同步
     *
     */
}
