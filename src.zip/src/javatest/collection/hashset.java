package javatest.collection;

import java.util.HashSet;

public class hashset {
    /**
     * 底层使用hashmap实现，允许null值
     *
     * HashSet添加的元素是存放在HashMap的key位置上
     *
     * 具体去看hashmap吧
     */
}
