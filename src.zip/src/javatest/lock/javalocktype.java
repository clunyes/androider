package javatest.lock;

public class javalocktype {

    /**
     * 讲一讲AtomicInteger，为什么要用CAS而不是synchronized？
     */
    /**
     * 偏向锁
     *
     * https://www.zhihu.com/question/55075763
     */
}
