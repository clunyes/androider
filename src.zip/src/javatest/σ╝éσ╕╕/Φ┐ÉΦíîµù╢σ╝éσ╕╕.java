package javatest.异常;

public class 运行时异常 {
    /**
     * ClassCastException(类转换异常)
     *
     * IndexOutOfBoundsException(数组越界)
     *
     * NullPointerException(空指针)
     *
     * ArrayStoreException(数据存储异常，操作数组时类型不一致)
     *
     * 还有IO操作的BufferOverflowException异常
     */
}
