package javatest.注解;

public class 实现 {
    /**
     *
     * @Retention(RUNTIME) @Target(FIELD)
     * public @interface BindView {
     *   /** View ID to which the field will be bound.
     *@IdRes int value();
     *}
     *
     *
     *
     *
     */
    //@interface就是注解的定义，Retention，Target就是元注解
}
