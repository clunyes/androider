package sourcecode.eventbus;

public class eventbus缺点 {
    /**
     *     1.只要用得一多，那消息类的数量必然是会爆炸性增长。
     *     2.调试的时候除非熟悉整块逻辑，不然不跑起来你是没办法了解Subscribe的方法的数据来源。
     */
}
