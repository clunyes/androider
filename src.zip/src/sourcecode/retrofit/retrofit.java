package sourcecode.retrofit;

public class retrofit {
    /**
     * Builder设置了默认的:平台类型对象：Android ,网络请求适配器工厂：CallAdapterFactory 数据转换器工厂 converter
     *
     * converter数据格式转换
     *
     * 默认根据platform获取：请求转换器返回的实体的转换
     */
    /**
     * retrofit接口的形式封装了请求
     * 请求时主要是注解的解释
     */
}
