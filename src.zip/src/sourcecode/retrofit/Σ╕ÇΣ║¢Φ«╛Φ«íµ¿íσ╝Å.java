package sourcecode.retrofit;

public class 一些设计模式 {
    /**
     * 单例 工厂就不用说了
     */
    /**
     * 适配器，外观retrofit.create()，代理必不可少
     */
}
