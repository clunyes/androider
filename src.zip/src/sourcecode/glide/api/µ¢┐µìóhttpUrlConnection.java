package sourcecode.glide.api;

public class 替换httpUrlConnection {
    /**
     * 替换请求内核
     * https://www.jianshu.com/p/a42ecf4af737 参考
     */
}
