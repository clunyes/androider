package sourcecode.glide.api;

public class requsetOption {
    /**
     *  RequestOption 可以被组合使用。如果 RequestOptions 对象之间存在相互冲突的设置，那么只有最后一个被应用的 RequestOptions 会生效。
     */
}
