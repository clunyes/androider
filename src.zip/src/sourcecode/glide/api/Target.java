package sourcecode.glide.api;

public class Target {
    /**
     *Glide.with(fragment)
     *   .load(url)
     *   .into(imageView);
     *
     * // Some time in the future:
     * Glide.with(fragment).clear(imageView);
     *
     *
     */
}
