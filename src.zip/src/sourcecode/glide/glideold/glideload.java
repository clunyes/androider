package sourcecode.glide.glideold;

public class glideload {
    /**
     * RequestManger load步骤
     * 将数据传递给requestManager
     */
}
