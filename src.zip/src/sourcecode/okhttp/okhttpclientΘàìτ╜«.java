package sourcecode.okhttp;

public class okhttpclient配置 {
    /**
     *
     * public Builder() {
     *       dispatcher = new Dispatcher();  //异步请求调度器
     *       protocols = DEFAULT_PROTOCOLS;//请求协议集合，默认为http/1.1和Http/2
     *       connectionSpecs = DEFAULT_CONNECTION_SPECS;//连接规格
     *       eventListenerFactory = EventListener.factory(EventListener.NONE);//事件监听器
     *       proxySelector = ProxySelector.getDefault();//代理选择器
     *       cookieJar = CookieJar.NO_COOKIES;//http cookies 提供持久化策略
     *       socketFactory = SocketFactory.getDefault(); //socket工厂类
     *       hostnameVerifier = OkHostnameVerifier.INSTANCE;//对host基本接口的验证
     *       certificatePinner = CertificatePinner.DEFAULT; //约束的信任证书
     *       proxyAuthenticator = Authenticator.NONE;//代理身份认证
     *       authenticator = Authenticator.NONE;
     *       connectionPool = new ConnectionPool();//连接复用池
     *       dns = Dns.SYSTEM;//默认使用系统的dns
     *       followSslRedirects = true; //遵循SSL重定向
     *       followRedirects = true;//普通重定向
     *       retryOnConnectionFailure = true;//连接失败后进行重新连接
     *       connectTimeout = 10_000;//连接超时时间
     *       readTimeout = 10_000;//读取数据超时时间
     *       writeTimeout = 10_000;//发送数据超时时间
     *       pingInterval = 0;//时间间隔
     *     }
     */
}
