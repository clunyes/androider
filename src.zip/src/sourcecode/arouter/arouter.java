package sourcecode.arouter;

public class arouter {
    /**
     * 1，模块之间的activity是不能通过原生去跳转的，这是router首要解决的问题。
     * 2，router没有intent传参大小限制的问题。
     * 3，router有强大的拦截器和降级
     * 4，router可以是模块之间通信的重要手段，如服务的发现等。
     * 5，对组件化的埋点和统计等有着很好的帮助。
     */
}
