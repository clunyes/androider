package sourcecode.leakCanary;

public class notice {
    /**
     * 在leakcanary2之后，heap分析已经从haha转成shark了
     */
}
