package language.python;

public class python的迭代器 {
    /**
     * 我们已经知道，可以直接作用于for循环的数据类型有以下几种：

     一类是集合数据类型，如list、tuple、dict、set、str等；

     一类是generator，包括生成器和带yield的generator function。
     */
}
