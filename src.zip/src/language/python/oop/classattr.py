class Student(object):
	name='hege'
	"""docstring for ClassName"""

s = Student()
print(s.name)
# del s.name 一直报错，懵
# print(s.name)