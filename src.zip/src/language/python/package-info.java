package language.python;
/**
 * 学习python过程中，有注意点都放在这里
 *
 * python代码都是可以运行的
 */