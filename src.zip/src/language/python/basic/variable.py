a = 'abc'
b = a
a = 'xyz'
print(b)