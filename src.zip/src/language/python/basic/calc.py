print(10/3)
print(9/3)
print(10//3)