print(True and True)
print(True and False)
print(True or False)
print(5>3 and 1>3)