# age = 20
# if age>18:
# 	print('你',age,'岁了,你是个大人')

# age = 3
# if age>18:
# 	print('你',age,'岁了,你是个大人')
# else:
# 	print('你',age,'岁了,你是个骚年')

age = 3
if age>18:
	print('大人')
elif age >6:
	print('骚年')
else:
	print('幼儿')