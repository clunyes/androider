print('name:', name, 'age:', age, 'other:', kw)# set和dict类似，也是一组key的集合，但不存储value。由于key不能重复，所以，在set中，没有重复的key。

# 要创建一个set，需要提供一个list作为输入集合：

s = set(['a','b','c','a']);
print(s)
# 上面我们讲了，str是不变对象，而list是可变对象。
a = 'abc'
print(a.replace('a','A'))
print(a)