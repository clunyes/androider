# print('hello world','天下无敌')
# print(100+200)
# print(890)
# print(1024*768)
# print('I\'m \"Ok\"')
# print('I\'m learning\npython')
# print(r'''hello,\n
# 	world''')
print('''line1
... line2
... line3''')