print('hello ,%s' % 'world')
print('hei,%s you have $%d!!!!' %('康哥',500000000))