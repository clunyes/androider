# name = input('请输入你的姓名')
# print('你好',name)

birth = input('输入你的出生年份')
birth = int(birth)
if birth>2000:
	print('00后')
else:
	print('00前')