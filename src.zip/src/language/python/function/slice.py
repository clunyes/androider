# Python提供了切片（Slice）操作符，能大大简化这种操作
L = ['Michael', 'Sarah', 'Tracy', 'Bob', 'Jack']
# L[0:3]表示，从索引0开始取，直到索引3为止，但不包括索引3。
print(L[1:3])