import deff,sys
print(deff.my_abs(22))
print(sys.path)