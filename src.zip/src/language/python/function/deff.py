def my_abs(x):
	if x>=0:
		return x
	else :
		return -x

print(my_abs(-12))		

# def my_abs(x):
# 	if not isinstance(x , (int ,float)):
# 		raise TypeError('错误类型')

# print(my_abs('sdaas'))