import os
for d in os.listdir('.'):
	print(d)