package project.架构之路;

public class 功能service组件 {
    /**
     * arouter
     * eventbus
     * webview模块(包含基础配置，安全检查)
     * 分享模块
     * 数据统计模块
     * 定位模块
     * 权限管理
     * 与业务没有关联的（一般项目刚开始不会直接做这块的工作）
     */
}
