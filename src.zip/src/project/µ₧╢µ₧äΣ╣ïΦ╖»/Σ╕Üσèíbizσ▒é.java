package project.架构之路;

public class 业务biz层 {
    /**
     * 订单
     * 消息
     * 商品
     * 具体业务具体来
     * 资讯类的（新闻）
     * 教育类的（课程）
     * 短视频（视频播放）
     *
     */

    /**
     * 业务层都可以单独打包app，gradle.properties配置参数，是否module打包
     */
}
