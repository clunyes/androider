package project.架构之路;

public class 分层 {
    /**
     *
     *    内核层（base）
     *    功能组件（service）
     *    业务模块层（biz）
     *    应用层（app）
     *
     *    页面跳转使用arouter，组件之间通信使用eventbus
     *
     */
}
