package project;

public class lazyhero {
    /**
     * 输入法项目
     * 输入法内核用的librime编译出来的so库
     * 词库数据库的提前编译导入项目assets目录
     * 输入法主要针对InputMethodService做封装，查看google文档，理解输入法的生命周期
     * 中英文数字键盘的布局，适配
     * 输入法联想功能：sougou词库中，寻找合适的词组成基础词库，txt文件。批量导入数据库，形成本地数据库。
     * 采用搜索匹配的方式完成联想功能
     *
     */
}
