package project;

public class shopguide {
    /**
     * shopguide总结
     */
    /**
     * base lib库
     * 1. glide图片
     * 2. orm--greenDao,ormLite
     * 3. retrofit+okHttp3
     * 4. fragmentation
     * 5. butterknife 注解形式，view初始化绑定
     * 6. agentweb webview的封装，处理webview的兼容问题
     * 7. utilcode通用的util工具
     * 8. 常用的列表组件BaseRecyclerViewAdapterHelper，下拉刷新上拉加载
     * 9. lottie动画
     *
     * 基础的网络请求通用处理，封装
     * activity fragment dialog的基础处理，通用封装.（业务项目针对当前项目业务，基于base逻辑，再做一层封装，满足业务需要）
     *
     *
     * 目的：分离业务代码和框架代码，同一版本管理config.gradle
     */
    /**
     * 业务代码：
     * 针对当前项目业务，基于base逻辑，再做一层封装，满足业务需要
     * 常量统一管理（注释说明）
     * 配置统一管理，sp
     * trace埋点单独模块处理
     *
     */

}
