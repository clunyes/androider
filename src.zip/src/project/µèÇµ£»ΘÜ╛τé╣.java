package project;

public class 技术难点 {
    /**
     * 联想词库，寻找解决方案---设计解决方案---demo尝试---落地
     */
    /**
     * jsBridge规范定制，建立基础的h5原生交互基础，方便开发
     * 1. 业务无关的jsbridge
     * 2. 业务相关的jsbridge
     */
}
