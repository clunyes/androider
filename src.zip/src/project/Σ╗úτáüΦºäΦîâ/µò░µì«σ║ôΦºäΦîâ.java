package project.代码规范;

public class 数据库规范 {
    /**
     * sqlite进行开发
     *
     */
}
