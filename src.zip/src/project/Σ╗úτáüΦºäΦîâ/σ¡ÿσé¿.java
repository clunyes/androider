package project.代码规范;

public class 存储 {
    /**
     * 1. 当使用外部存储时，必须检查外部存储的可用性。
     */
}
